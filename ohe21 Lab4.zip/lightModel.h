/***************************************************************************
 *
 *
 */

// Object is the base class for objects.
#ifndef _LIGHTMODEL_H_
#define _LIGHTMODEL_H_

class LightModel {
public:

  virtual float getCoeff()
  {

  }

};

#endif
