/***************************************************************************
*
* ohe - Oliver's Raytracer - Coursework Edition. (C) Copyright 1997-2019.
*
* Do what you like with this code as long as you retain this comment.
*/

#pragma once

class Object;

class Raytracer {
public:

};
