Raytracer::Raytracer()
{
	// Use the Barycentric co-ords 
}